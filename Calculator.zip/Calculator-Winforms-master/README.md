# Calculator-Winforms
Calculator using Winforms, C#

In this tutorial, we will focus on how to design a layout for minimal calculator app which will be built using Microsoft's Windows Forms.

We will concentrate more about how to adjust and fit in various controls like Button, TextBox and Table Layout Panel and its spacing, adjustment rather than on the calculator logic.

Windows Forms often called as WinForms is a .NET's revolutionary framework for building Windows Applications. It has grown its popularity over the years due to its flexibility and still is a strong contender in the windows application development space to WPF (Windows Presentation Foundation).
